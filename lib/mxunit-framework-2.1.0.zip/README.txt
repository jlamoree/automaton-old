 MXUnit is a unit test framework for CFML. 
 
 Main website: http://mxunit.org
 
 Docs, etc: http://wiki.mxunit.org
 
 Bugs and enhancements: http://jira.mxunit.org
 
 SVN: http://mxunit.googlecode.com/svn/mxunit/trunk
 
 MXUnit Google Group (to get help): http://groups.google.com/group/mxunit
 
 Version Info: This is a nightly build of the 2.0.3 stream, built on 09/09/2011