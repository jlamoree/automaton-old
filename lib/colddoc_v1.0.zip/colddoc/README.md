ColdDoc 1.0
==========

Thanks for taking the time to look at ColdDoc!

The ColdDoc home page can be found at [http://www.compoundtheory.com/?action=colddoc.index][1]

Documentation for ColdDoc can be found on the [GitHub Wiki][2].

The main Git repository and downloads can be found on [GitHub][3].

For support, the ColdDoc mailing list can be found on [Google Groups][4].

[1]: http://www.compoundtheory.com/?action=colddoc.index
[2]: https://github.com/markmandel/ColdDoc/wiki
[3]: https://github.com/markmandel/ColdDoc
[4]: https://groups.google.com/forum/#!forum/colddoc-dev

