To install into CF Builder, Navigate to Eclipse Preferences - ColdFusion/Extensions

Click on Import and select the parent folder where you extracted varscoper.zip